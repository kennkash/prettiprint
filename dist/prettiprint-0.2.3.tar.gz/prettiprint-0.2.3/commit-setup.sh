# setup pre-commit/gitlint
pre-commit install --hook-type commit-msg
